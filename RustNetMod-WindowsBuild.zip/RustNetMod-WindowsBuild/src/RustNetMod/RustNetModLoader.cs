using Game;

namespace RustNetMod;

/// <summary>
/// Minimal NetMod entry point. Keep this first build deliberately small:
/// the first goal is to verify that the target server discovers and loads
/// the .netmod package before adding gameplay systems.
/// </summary>
public sealed class RustNetModLoader : ModLoader
{
    public override void __ModInitialize()
    {
        // Initialization placeholder. Feature hooks will be added after
        // the minimal package has been verified in the target server.
    }
}
