# RustNetMod Windows 云端编译工程（最小加载验证版）

当前目标：先编译出最小 `.netmod`，验证服务端能否发现并加载，再继续加入 Rust 风格玩法系统。

## 已确定的工程配置
- TargetFramework：`net10.0`
- 编译平台：Windows x64（GitHub Actions `windows-latest`）
- 引用程序集：`Survivalcraft.dll`、`Engine.dll`、`EntitySystem.dll`
- 输出：`artifacts/RustNetMod.netmod`

## 准备服务端 DLL
从你上传的服务端压缩包 `服务端X26.07.01.01-1.zip` 内的 `net10.0/` 目录取出以下三个文件，放到本工程 `build-libs/`：
1. `Survivalcraft.dll`
2. `Engine.dll`
3. `EntitySystem.dll`

只需要这三个编译引用文件，不要把整个服务端目录上传到仓库。

## Windows 本机编译
安装 .NET 10 SDK 后，在 PowerShell 进入工程目录运行：

```powershell
./build-netmod.ps1
```

## Windows 云端编译（不需要把 GitHub 账号连接到 ChatGPT）
1. 在 GitHub 网页创建一个空仓库。
2. 将本工程文件上传到仓库根目录。
3. 将上面三个 DLL 上传到 `build-libs/` 目录。
4. 打开仓库的 Actions 页面，选择 `Build RustNetMod (.netmod)`，点击 `Run workflow`。
5. 构建成功后，进入该次运行页面，在 Artifacts 下载 `RustNetMod-netmod`，解压后得到 `RustNetMod.netmod`。

注意：GitHub Actions 需要你自己的 GitHub 账号和手动启动权限；这不等于把 GitHub 连接给 ChatGPT。当前会话不能替你登录或点击 GitHub。

## 重要说明
- 这是最小加载验证骨架，不是已完成的 Rust 生存玩法 Mod。
- `ApiVersion=1.44`、`ScVersion=2.4.40.6` 沿用你提供的 SurvivalcraftRuins 示例项目打包脚本中的 NetMod 元数据值；尚未在你这份 x26.07.01.01 服务端上实机验证。
- 编译成功只代表 DLL 成功生成；还需要把 `.netmod` 放进服务端 `NetMods/` 并启动，确认加载日志后，才能进入玩法功能开发。
