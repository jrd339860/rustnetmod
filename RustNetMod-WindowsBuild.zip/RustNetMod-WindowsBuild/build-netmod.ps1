param(
    [string]$GameDllDir = (Join-Path $PSScriptRoot 'build-libs')
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$src = Join-Path $root 'src/RustNetMod'
$outDir = Join-Path $root 'artifacts'
$stage = Join-Path $outDir '_stage'
$package = Join-Path $outDir 'RustNetMod.netmod'

$required = @('Survivalcraft.dll', 'Engine.dll', 'EntitySystem.dll')
foreach ($name in $required) {
    if (-not (Test-Path (Join-Path $GameDllDir $name))) {
        throw "Missing $name in '$GameDllDir'. Extract it from the target server's net10.0 folder."
    }
}
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw '.NET 10 SDK is required. Install the .NET 10 SDK before running this script.'
}

New-Item -ItemType Directory -Force -Path $outDir | Out-Null
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $stage | Out-Null
$gameDllDirFull = (Resolve-Path $GameDllDir).Path.TrimEnd('\') + '\'

dotnet build (Join-Path $src 'RustNetMod.csproj') -c Release "-p:SurvivalcraftDir=$gameDllDirFull"
if ($LASTEXITCODE -ne 0) { throw 'dotnet build failed.' }

$dll = Join-Path $src 'bin/Release/net10.0/RustNetMod.dll'
if (-not (Test-Path $dll)) { throw "Build output not found: $dll" }
Copy-Item $dll $stage

# Emit the NetMod metadata shape used by the supplied SurvivalcraftRuins
# NetMod packaging script. These version values come from that reference
# project's packager and still require in-game compatibility verification.
$info = Get-Content (Join-Path $src 'modinfo.json') -Raw | ConvertFrom-Json
$netInfo = [ordered]@{
    Name = $info.Name
    Version = $info.Version
    ApiVersion = '1.44'
    Description = $info.Description
    ScVersion = '2.4.40.6'
    Link = $info.Link
    Author = $info.Author
    PackageName = $info.PackageName
    Dependencies = @()
}
$netInfo | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $stage 'modinfo.json') -Encoding utf8

if (Test-Path $package) { Remove-Item $package -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $package)
Remove-Item $stage -Recurse -Force
Write-Host "Created: $package"
