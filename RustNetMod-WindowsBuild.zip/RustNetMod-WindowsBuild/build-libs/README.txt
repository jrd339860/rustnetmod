Place these three reference assemblies here before building:
- Survivalcraft.dll
- Engine.dll
- EntitySystem.dll

Use the files from the target server archive's net10.0/ directory.
Do not use the client DLLs unless they are confirmed to be identical.
